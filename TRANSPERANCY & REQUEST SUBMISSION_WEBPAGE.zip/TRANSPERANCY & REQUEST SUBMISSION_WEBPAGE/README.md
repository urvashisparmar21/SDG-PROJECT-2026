# 🏛️ Transparency Youth Network (TYN)

[Next.js](https://www.google.com/search?q=https%3A%2F%2Fnextjs.org%2F)
[Express.js](https://www.google.com/search?q=https%3A%2F%2Fexpressjs.com%2F)
[PostgreSQL](https://www.google.com/search?q=https%3A%2F%2Fwww.postgresql.org%2F)
[Docker](https://www.google.com/search?q=https%3A%2F%2Fwww.docker.com%2F)
[License: MIT](https://www.google.com/search?q=LICENSE)

> **An open-source, full-stack civic accountability platform connecting youth advocates with municipal oversight to report local infrastructure issues, verify resolutions, and audit transparent public data in real time.**

---

## 📖 Table of Contents
- [Project Vision](#-project-vision)
- [System Architecture & Data Flow](#-system-architecture--data-flow)
- [Key Features](#-key-features)
- [Technology Stack](#-technology-stack)
- [Repository Structure](#-repository-structure)
- [Quickstart (Docker Compose)](#-quickstart-docker-compose-recommended)
- [Manual Setup (Local Node & PostgreSQL)](#-manual-setup-local-node--postgresql)
- [Pre-Seeded Test Accounts](#-pre-seeded-test-accounts)
- [REST API Reference](#-rest-api-reference)
- [Automated Testing](#-automated-testing)
- [Security & Compliance](#-security--compliance)
- [Contributing & License](#-contributing--license)

---

## 🌍 Project Vision

Local infrastructure decay, streetlight failures, and neglected public utilities disproportionately affect youth safety and community welfare. The **Transparency Youth Network** provides an immutable, transparent ledger where youth civic groups can document community challenges, monitor governmental progress, and track resolution audits without bureaucratic opacity.

---

## 🏗️ System Architecture & Data Flow

### Level 0 DFD (Context Diagram)
```text
  +-----------------------------------------------------------+
  |                     Youth / Citizen                       |
  +-----------------------------------------------------------+
         |                                             ^
    Issue Submission & GPS Coordinates                 | Submission Confirmation
    Community Comments & Observations                  | Transparent Public Registry
         v                                             |
  +===========================================================+
  |             [ 0.0 Transparency Youth Network ]            |
  +===========================================================+
         ^                                             |
         | Status Updates / Work Order Numbers         | Real-time Feed & Metrics
         v                                             v
  +-------------------------------+     +-----------------------------+
  |   Civic Authority / Admin     |     |   Public Visitor / Media    |
  +-------------------------------+     +-----------------------------+
```

### Level 1 DFD (Decomposed Core Engine)
```text
[ Youth Advocate ] ---> (Credentials) ------> [ 1.0 Identity Service ] ------> [(D1) Users DB]
                   ---> (Issue Report + GPS)-> [ 2.0 Ingestion Engine ] ------> [(D2) Reports DB]
                   ---> (Comments) ---------> [ 3.0 Engagement Engine ] ------> [(D3) Comments DB]

[ Civic Authority] ---> (Audit / Verify) ---> [ 4.0 Moderation Hub ] --------> [(D2) Status Update]
[ Public Visitor ] <--- (Filter & Search) --- [ 5.0 Transparency Feed ] <----- [(D2) Public Views]
```

---

## ✨ Key Features

1. **Precision Geolocation Reporting**:
   - One-click client GPS auto-detection with fallback for standard Wi-Fi and manual coordinate input.
   - Bounded coordinate validation enforcing strict latitude (`-90` to `90`) and longitude (`-180` to `180`) limits.
2. **Transparent Public Registry**:
   - Filterable civic dashboard categorized by *Infrastructure*, *Sanitation*, *Public Safety*, *Environment*, and *Education*.
   - Dynamic status badges: `Submitted`, `Under Review`, `In Progress`, `Resolved`, and `Dismissed`.
3. **Role-Based Access Control (RBAC)**:
   - Three distinct domain tiers: `youth` (reporters), `moderator` (civic authority oversight), and `admin` (system audit).
   - Strict privilege separation preventing unauthorized status alterations on public records.
4. **Official Audit Trail & Discussions**:
   - Community comment threads paired with verified official governmental responses.
5. **Containerized Production Architecture**:
   - Isolated multi-stage Docker builds running under non-privileged system users with automatic container health monitoring.

---

## 🛠️ Technology Stack

| Layer | Technology | Key Capabilities |
| :--- | :--- | :--- |
| **Frontend UI** | **Next.js 14**, React 18, Tailwind CSS | App Router, responsive grid, dynamic filtering, stateful form validation |
| **Backend API** | **Node.js 20**, Express (ES Modules) | REST API, Helmet security headers, CORS management, Morgan logger |
| **Authentication** | **JWT (RFC 7519)** & Bcrypt.js | Stateless bearer tokens, role claims verification, salted password hashes |
| **Database** | **PostgreSQL 16** | `pgcrypto` UUIDs, domain ENUMs, spatial coordinate indexing, triggers |
| **Orchestration** | **Docker** & Docker Compose | Multi-stage production images, dumb-init PID supervisor, health checks |

---

## 📁 Repository Structure

```text
transparency-youth-network/
├── docker-compose.yml              # Container orchestration (PostgreSQL, Express, Next.js)
├── .env.example                    # Global environment configuration template
├── README.md                       # Comprehensive platform documentation
├── database/
│   └── init.sql                    # PostgreSQL schema, ENUMs, triggers & seed records
├── backend/
│   ├── Dockerfile                  # Multi-stage production container build
│   ├── package.json                # Dependencies (Express, pg, JWT, bcrypt, helmet)
│   ├── .env.example                # Backend runtime configuration
│   ├── tests/
│   │   └── reports.test.js         # Zero-dependency architectural test suite (9 tests)
│   └── src/
│       ├── server.js               # Express application entrypoint & middleware
│       ├── config/
│       │   └── db.js               # PostgreSQL connection pool & health hooks
│       ├── middleware/
│       │   └── auth.js             # JWT verification & RBAC role guards
│       ├── controllers/
│       │   ├── authController.js   # User registration, login, and session validation
│       │   ├── reportsController.js# Issue CRUD, geo-queries, and pagination
│       │   └── commentsController.js# Community engagement & official agency responses
│       └── routes/
│           ├── authRoutes.js       # /api/auth endpoints
│           └── reportsRoutes.js    # /api/reports endpoints
└── frontend/
    ├── Dockerfile                  # Next.js multi-stage production runner
    ├── package.json                # Dependencies (Next.js, React, Tailwind CSS)
    ├── .env.example                # Frontend environment configuration
    ├── next.config.js              # Next.js build options
    ├── tailwind.config.js          # Tailwind theme tokens & design system
    └── src/
        ├── app/
        │   ├── globals.css         # Tailwind directives & CSS resets
        │   ├── layout.jsx          # Root layout shell
        │   └── page.jsx            # Dynamic homepage & tab controller
        └── components/
            ├── Navbar.jsx          # Top navigation bar
            ├── CivicMetricsBanner.jsx # Real-time civic metrics counter
            ├── SubmitReportForm.jsx   # Issue reporting wizard with GPS auto-detection
            └── PublicTransparencyDashboard.jsx # Filterable civic feed & cards
```

---

## 🚀 Quickstart (Docker Compose - Recommended)

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/transparency-youth-network.git
cd transparency-youth-network
```

### 2. Configure Environment Variables
Copy the master environment template:
```bash
cp .env.example .env
```

### 3. Launch the Stack
Run the Docker Compose launch command:
```bash
docker compose up --build -d
```

### 4. Access the Live Services
* **Public Web Dashboard**: [http://localhost:3000](https://www.google.com/search?q=http%3A%2F%2Flocalhost%3A3000)
* **Backend API Health Probe**: [http://localhost:5050/health](https://www.google.com/search?q=http%3A%2F%2Flocalhost%3A5050%2Fhealth)
* **PostgreSQL Database**: `localhost:5432` (`transparency_network_db`)

---

## 💻 Manual Setup (Local Node & PostgreSQL)

If you prefer to run the application directly on your host machine without Docker:

### 1. Initialize PostgreSQL Database
Make sure PostgreSQL 14+ is running locally:
```bash
createdb -U postgres transparency_network_db
psql -U postgres -d transparency_network_db -f database/init.sql
```

### 2. Start the Backend API
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
*API server will listen on `http://localhost:5050`.*

### 3. Start the Next.js Frontend
```bash
cd ../frontend
cp .env.example .env.local
npm install
npm run dev
```
*Frontend will launch on `http://localhost:3000`.*

---

## 👥 Pre-Seeded Test Accounts

The platform includes pre-seeded accounts in `database/init.sql` for instant local testing:

| Role | Name | Email | Password | Allowed Capabilities |
| :--- | :--- | :--- | :--- | :--- |
| **Youth** | Aarav Patel | `aarav.patel@youthnet.org` | `Password123!` | Submit issues, participate in community discussion threads |
| **Moderator** | Priya Sharma | `priya.sharma@civicgov.org` | `Password123!` | Review issues, update status to *In Progress* or *Resolved*, post official municipal replies |
| **Admin** | Devon Vance | `admin@transparency.org` | `Password123!` | System oversight, role promotion, full report audit and moderation |

---

## 📡 REST API Reference

### Authentication Endpoints
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Public | Register a new user (`full_name`, `email`, `password`, `role`) |
| `POST` | `/api/auth/login` | Public | Sign in and receive a signed Bearer JWT token |
| `GET` | `/api/auth/me` | Protected | Fetch current session and user profile |

### Reports & Civic Endpoints
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/reports` | Public | Fetch paginated reports feed (supports `category`, `status`, `search`) |
| `GET` | `/api/reports/:id` | Public | Retrieve detailed report with comment history |
| `POST` | `/api/reports` | Protected (Youth+) | Submit a new community issue report with geographic coordinates |
| `PATCH` | `/api/reports/:id/status` | Protected (Mod/Admin) | Update report status (`submitted`, `under_review`, `in_progress`, `resolved`, `dismissed`) |
| `POST` | `/api/reports/:id/comments`| Protected (All) | Add community comment or official agency response |

---

## 🧪 Automated Testing

The backend includes a zero-dependency automated test suite covering authentication, coordinate boundaries, and role permissions:

```bash
cd backend
node tests/reports.test.js
```

### Verified Test Cases
- `TC-AUTH-01`: Valid JWT signature generation and claims decoding.
- `TC-AUTH-03`: Rejection of unauthenticated requests missing Bearer tokens.
- `TC-AUTH-04`: Token expiration validation and handling.
- `TC-REP-01`: Valid report submission with geospatial coordinates.
- `TC-REP-02`: Rejection of missing mandatory title and short description.
- `TC-REP-03`: Rejection of out-of-bounds latitude/longitude values.
- `TC-RBAC-01`: Enforcement preventing unauthorized status updates by youth role.
- `TC-RBAC-02`: Verification of status change permissions for moderator role.
- `TC-RBAC-03`: Verification of administrative oversight permissions.

---

## 🔒 Security & Compliance

* **SQL Injection Prevention**: All queries execute through parameterized inputs (`$1`, `$2`, ...).
* **Password Hashing**: Stored passwords use bcrypt with a salt factor of 10.
* **Tamper-Resistant Identifiers**: Primary keys generated via PostgreSQL `gen_random_uuid()`.
* **Container Hardening**: Containers run under unprivileged system users (`node` and `nextjs`) with non-root privileges.
* **Process Supervisors**: `dumb-init` handles PID 1 signal forwarding and prevents zombie processes.

---

## 🤝 Contributing

Contributions from youth civic technologists and developers worldwide are welcome!

1. Fork the Project Repository.
2. Create your Feature Branch (`git checkout -b feature/CivicFeature`).
3. Commit your Changes (`git commit -m 'Add interactive leaflet map layer'`).
4. Push to the Branch (`git push origin feature/CivicFeature`).
5. Open a Pull Request.

---

## 📄 License

Distributed under the **MIT License**. See `LICENSE` for more information.
