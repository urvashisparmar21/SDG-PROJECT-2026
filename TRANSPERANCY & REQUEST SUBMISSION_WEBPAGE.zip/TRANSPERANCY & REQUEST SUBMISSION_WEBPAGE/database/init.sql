-- ==============================================================================
-- TRANSPARENCY YOUTH NETWORK - DATABASE INITIALIZATION SCHEMA & SEED DATA
-- PostgreSQL Schema with RBAC, Geospatial Coordinates, and Referential Integrity
-- ==============================================================================

-- 1. Enable Cryptographic Functions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Enumerated Domain Types
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('youth', 'moderator', 'admin');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE report_status AS ENUM ('submitted', 'under_review', 'in_progress', 'resolved', 'dismissed');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE report_category AS ENUM (
        'infrastructure',
        'sanitation',
        'education',
        'environment',
        'public_safety',
        'governance',
        'other'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. Users Table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'youth',
    organization VARCHAR(150),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- 4. Reports Table
CREATE TABLE IF NOT EXISTS reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id UUID NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    category report_category NOT NULL,
    status report_status NOT NULL DEFAULT 'submitted',
    latitude NUMERIC(9, 6) NOT NULL,
    longitude NUMERIC(9, 6) NOT NULL,
    address_text VARCHAR(255),
    media_urls TEXT[] DEFAULT ARRAY[]::TEXT[],
    view_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reports_author FOREIGN KEY (author_id) 
        REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT chk_title_length CHECK (char_length(trim(title)) >= 5),
    CONSTRAINT chk_description_length CHECK (char_length(trim(description)) >= 20),
    CONSTRAINT chk_valid_latitude CHECK (latitude >= -90.0 AND latitude <= 90.0),
    CONSTRAINT chk_valid_longitude CHECK (longitude >= -180.0 AND longitude <= 180.0)
);

-- 5. Comments & Engagement Table
CREATE TABLE IF NOT EXISTS comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id UUID NOT NULL,
    author_id UUID NOT NULL,
    content TEXT NOT NULL,
    is_official_response BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_comments_report FOREIGN KEY (report_id) 
        REFERENCES reports (id) ON DELETE CASCADE,
    CONSTRAINT fk_comments_author FOREIGN KEY (author_id) 
        REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT chk_comment_content CHECK (char_length(trim(content)) > 0)
);

-- 6. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE INDEX IF NOT EXISTS idx_reports_author_id ON reports(author_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_category ON reports(category);
CREATE INDEX IF NOT EXISTS idx_reports_created_at_desc ON reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_geo ON reports(latitude, longitude);

CREATE INDEX IF NOT EXISTS idx_comments_report_id_created_at ON comments(report_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_comments_author_id ON comments(author_id);

-- 7. Automatic Updated_At Trigger Function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_users_updated_at ON users;
CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_reports_updated_at ON reports;
CREATE TRIGGER trg_reports_updated_at
    BEFORE UPDATE ON reports
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_comments_updated_at ON comments;
CREATE TRIGGER trg_comments_updated_at
    BEFORE UPDATE ON comments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==============================================================================
-- SEED DATA (For Local Development, Testing, and Demonstrations)
-- ==============================================================================

-- Passwords below are bcrypt hashes of "Password123!" with salt rounds 10:
-- $2a$10$wE6y7NfPqLh.B.jXl9J5he0tYt4xUjJgV/kYVqH.2sO2vXbK5mG9e
INSERT INTO users (id, full_name, email, password_hash, role, organization)
VALUES
    ('11111111-1111-1111-1111-111111111111', 'Aarav Patel', 'aarav.patel@youthnet.org', '$2a$10$wE6y7NfPqLh.B.jXl9J5he0tYt4xUjJgV/kYVqH.2sO2vXbK5mG9e', 'youth', 'Youth Climate Action Club'),
    ('22222222-2222-2222-2222-222222222222', 'Priya Sharma', 'priya.sharma@civicgov.org', '$2a$10$wE6y7NfPqLh.B.jXl9J5he0tYt4xUjJgV/kYVqH.2sO2vXbK5mG9e', 'moderator', 'Municipal Civic Oversight Board'),
    ('33333333-3333-3333-3333-333333333333', 'Devon Vance', 'admin@transparency.org', '$2a$10$wE6y7NfPqLh.B.jXl9J5he0tYt4xUjJgV/kYVqH.2sO2vXbK5mG9e', 'admin', 'Transparency Youth Network Global')
ON CONFLICT (email) DO NOTHING;

INSERT INTO reports (id, author_id, title, description, category, status, latitude, longitude, address_text, media_urls)
VALUES
    (
        'aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '11111111-1111-1111-1111-111111111111',
        'Broken Streetlights Near Community Learning Center',
        'Streetlights have been non-functional along the entire 400-meter walkway leading to the public library and youth center. Creates severe safety concerns during evening study sessions.',
        'public_safety',
        'under_review',
        22.303894,
        70.802160,
        'Kalavad Road, Opposite Central Library, Ward 7',
        ARRAY['https://images.unsplash.com/photo-1509198397868-475647b2a1e5']
    ),
    (
        'aaaaaaa2-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '11111111-1111-1111-1111-111111111111',
        'Blocked Storm Drainage Causing Waterlogging in Sector 4',
        'Plastic accumulation and silt runoff have completely clogged the main rainwater outlet. Stagnant water is blocking the pedestrian crossing and school bus bay.',
        'sanitation',
        'in_progress',
        22.285621,
        70.781245,
        'Sector 4 Roundabout, Near Government High School',
        ARRAY['https://images.unsplash.com/photo-1542601906990-b4d3fb778b09']
    ),
    (
        'aaaaaaa3-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '11111111-1111-1111-1111-111111111111',
        'Solar Powered Lighting Installed in Community Park',
        'Follow-up report: The municipal council completed installation of 12 solar lamps along the children running track as requested in civic petition #204.',
        'environment',
        'resolved',
        22.312040,
        70.814320,
        'Jubilee Children Memorial Park, North Gate',
        ARRAY['https://images.unsplash.com/photo-1473341304170-971dccb5ac1e']
    )
ON CONFLICT (id) DO NOTHING;

INSERT INTO comments (id, report_id, author_id, content, is_official_response)
VALUES
    (
        'ccccccc1-cccc-cccc-cccc-cccccccccccc',
        'aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '22222222-2222-2222-2222-222222222222',
        'Our field inspection unit has verified the electrical fault on Pole #14 and #16. Work order #CIV-482 has been issued to the municipal maintenance division.',
        TRUE
    ),
    (
        'ccccccc2-cccc-cccc-cccc-cccccccccccc',
        'aaaaaaa2-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '33333333-3333-3333-3333-333333333333',
        'Sanitation crew dispatched with excavation suction pump. Target completion within 24 hours.',
        TRUE
    )
ON CONFLICT (id) DO NOTHING;
