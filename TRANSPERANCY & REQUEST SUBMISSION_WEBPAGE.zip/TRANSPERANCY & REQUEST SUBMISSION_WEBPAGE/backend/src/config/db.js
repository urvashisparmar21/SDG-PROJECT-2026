import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const isProduction = process.env.NODE_ENV === 'production';

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProduction ? { rejectUnauthorized: false } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('connect', () => {
  if (!isProduction) {
    console.log('[Database] Connected to PostgreSQL instance.');
  }
});

pool.on('error', (err) => {
  console.error('[Database Error] Unexpected client idle error:', err.message);
});

export const query = (text, params) => pool.query(text, params);
