import { Router } from 'express';
import {
  createReport,
  getReports,
  getReportById,
  updateReportStatus,
} from '../controllers/reportsController.js';
import { addComment } from '../controllers/commentsController.js';
import { authenticateToken, requireRoles } from '../middleware/auth.js';

const router = Router();

// Public routes
router.get('/', getReports);
router.get('/:id', getReportById);

// Protected routes (Any authenticated youth, moderator, admin)
router.post('/', authenticateToken, createReport);
router.post('/:reportId/comments', authenticateToken, addComment);

// Moderation routes (Moderators and Admins only)
router.patch('/:id/status', authenticateToken, requireRoles('moderator', 'admin'), updateReportStatus);

export default router;
