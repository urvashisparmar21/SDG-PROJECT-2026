import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool } from '../config/db.js';

export const register = async (req, res) => {
  const { full_name, email, password, role = 'youth', organization } = req.body;

  if (!full_name || full_name.trim().length < 2) {
    return res.status(400).json({ success: false, error: 'Full name must be at least 2 characters.' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRegex.test(email.trim())) {
    return res.status(400).json({ success: false, error: 'A valid email address is required.' });
  }

  if (!password || password.length < 8) {
    return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.' });
  }

  const validRoles = ['youth', 'moderator', 'admin'];
  if (role && !validRoles.includes(role)) {
    return res.status(400).json({ success: false, error: 'Invalid user role specified.' });
  }

  try {
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email.trim().toLowerCase()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ success: false, error: 'An account with this email already exists.' });
    }

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 10;
    const password_hash = await bcrypt.hash(password, saltRounds);

    const insertQuery = `
      INSERT INTO users (full_name, email, password_hash, role, organization)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, full_name, email, role, organization, created_at;
    `;
    const { rows } = await pool.query(insertQuery, [
      full_name.trim(),
      email.trim().toLowerCase(),
      password_hash,
      role,
      organization ? organization.trim() : null,
    ]);

    const newUser = rows[0];
    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role, full_name: newUser.full_name },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    return res.status(201).json({
      success: true,
      message: 'User registered successfully.',
      token,
      user: newUser,
    });
  } catch (error) {
    console.error('[AuthController.register] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error registering user.' });
  }
};

export const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email and password are required.' });
  }

  try {
    const { rows } = await pool.query(
      'SELECT id, full_name, email, password_hash, role, organization, is_active FROM users WHERE email = $1',
      [email.trim().toLowerCase()]
    );

    if (rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const user = rows[0];
    if (!user.is_active) {
      return res.status(403).json({ success: false, error: 'This user account has been deactivated.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    const sanitizedUser = {
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      role: user.role,
      organization: user.organization,
    };

    return res.status(200).json({
      success: true,
      message: 'Signed in successfully.',
      token,
      user: sanitizedUser,
    });
  } catch (error) {
    console.error('[AuthController.login] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error during authentication.' });
  }
};

export const getMe = async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT id, full_name, email, role, organization, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, error: 'User profile not found.' });
    }
    return res.status(200).json({ success: true, user: rows[0] });
  } catch (error) {
    console.error('[AuthController.getMe] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error retrieving user profile.' });
  }
};
