import { pool } from '../config/db.js';

export const addComment = async (req, res) => {
  const { reportId } = req.params;
  const { content } = req.body;

  if (!content || content.trim().length === 0) {
    return res.status(400).json({ success: false, error: 'Comment content cannot be empty.' });
  }

  try {
    // Check if report exists
    const reportCheck = await pool.query('SELECT id FROM reports WHERE id = $1', [reportId]);
    if (reportCheck.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Target report not found.' });
    }

    const isOfficial = req.user.role === 'moderator' || req.user.role === 'admin';

    const insertQuery = `
      INSERT INTO comments (report_id, author_id, content, is_official_response)
      VALUES ($1, $2, $3, $4)
      RETURNING id, report_id, author_id, content, is_official_response, created_at;
    `;

    const { rows } = await pool.query(insertQuery, [
      reportId,
      req.user.id,
      content.trim(),
      isOfficial,
    ]);

    return res.status(201).json({
      success: true,
      message: 'Comment posted successfully.',
      data: {
        ...rows[0],
        author_name: req.user.full_name,
        author_role: req.user.role,
      },
    });
  } catch (error) {
    console.error('[CommentsController.addComment] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error posting comment.' });
  }
};
