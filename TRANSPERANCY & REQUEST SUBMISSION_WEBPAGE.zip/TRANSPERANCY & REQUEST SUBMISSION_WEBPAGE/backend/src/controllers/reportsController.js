import { pool } from '../config/db.js';

const VALID_CATEGORIES = [
  'infrastructure',
  'sanitation',
  'education',
  'environment',
  'public_safety',
  'governance',
  'other',
];

const VALID_STATUSES = ['submitted', 'under_review', 'in_progress', 'resolved', 'dismissed'];

/**
 * POST /api/reports
 * Secure route: Submits a new youth civic issue report.
 */
export const createReport = async (req, res) => {
  const {
    title,
    description,
    category,
    latitude,
    longitude,
    address_text,
    media_urls = [],
  } = req.body;

  const errors = [];
  if (!title || title.trim().length < 5) {
    errors.push('Title is required and must be at least 5 characters long.');
  }
  if (!description || description.trim().length < 20) {
    errors.push('Description is required and must be at least 20 characters long.');
  }
  if (!category || !VALID_CATEGORIES.includes(category)) {
    errors.push(`Invalid category. Allowed categories: ${VALID_CATEGORIES.join(', ')}`);
  }

  const latNum = parseFloat(latitude);
  const lngNum = parseFloat(longitude);
  if (isNaN(latNum) || latNum < -90 || latNum > 90) {
    errors.push('Latitude must be a valid number between -90 and 90.');
  }
  if (isNaN(lngNum) || lngNum < -180 || lngNum > 180) {
    errors.push('Longitude must be a valid number between -180 and 180.');
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  const insertQuery = `
    INSERT INTO reports (
      author_id,
      title,
      description,
      category,
      latitude,
      longitude,
      address_text,
      media_urls
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING id, author_id, title, description, category, status, latitude, longitude, address_text, media_urls, created_at;
  `;

  try {
    const values = [
      req.user.id,
      title.trim(),
      description.trim(),
      category,
      latNum,
      lngNum,
      address_text ? address_text.trim() : null,
      Array.isArray(media_urls) ? media_urls : [],
    ];

    const { rows } = await pool.query(insertQuery, values);

    return res.status(201).json({
      success: true,
      message: 'Civic report registered successfully.',
      data: rows[0],
    });
  } catch (error) {
    console.error('[ReportsController.createReport] Error:', error);
    return res.status(500).json({
      success: false,
      error: 'An internal server error occurred while persisting the report.',
    });
  }
};

/**
 * GET /api/reports
 * Public route: Fetches paginated transparency reports feed with optional filters.
 */
export const getReports = async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));
  const offset = (page - 1) * limit;

  const { status, category, search } = req.query;

  const conditions = [];
  const values = [];
  let paramIndex = 1;

  if (status) {
    conditions.push(`r.status = $${paramIndex++}`);
    values.push(status);
  }
  if (category) {
    conditions.push(`r.category = $${paramIndex++}`);
    values.push(category);
  }
  if (search) {
    conditions.push(`(r.title ILIKE $${paramIndex} OR r.description ILIKE $${paramIndex})`);
    values.push(`%${search.trim()}%`);
    paramIndex++;
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const dataQuery = `
    SELECT 
      r.id,
      r.title,
      r.description,
      r.category,
      r.status,
      r.latitude,
      r.longitude,
      r.address_text,
      r.media_urls,
      r.created_at,
      u.full_name AS author_name,
      u.role AS author_role,
      u.organization AS author_organization,
      COUNT(c.id)::int AS comments_count
    FROM reports r
    JOIN users u ON r.author_id = u.id
    LEFT JOIN comments c ON c.report_id = r.id
    ${whereClause}
    GROUP BY r.id, u.full_name, u.role, u.organization
    ORDER BY r.created_at DESC
    LIMIT $${paramIndex++} OFFSET $${paramIndex++};
  `;

  const countQuery = `
    SELECT COUNT(*)::int AS total
    FROM reports r
    ${whereClause};
  `;

  try {
    const [dataResult, countResult] = await Promise.all([
      pool.query(dataQuery, [...values, limit, offset]),
      pool.query(countQuery, values),
    ]);

    const total = countResult.rows[0].total;
    const totalPages = Math.ceil(total / limit);

    return res.status(200).json({
      success: true,
      data: dataResult.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    });
  } catch (error) {
    console.error('[ReportsController.getReports] Error:', error);
    return res.status(500).json({
      success: false,
      error: 'An internal server error occurred while retrieving reports.',
    });
  }
};

/**
 * GET /api/reports/:id
 * Public route: Retrieves single report details with comments thread.
 */
export const getReportById = async (req, res) => {
  const { id } = req.params;

  try {
    const reportQuery = `
      SELECT 
        r.id,
        r.title,
        r.description,
        r.category,
        r.status,
        r.latitude,
        r.longitude,
        r.address_text,
        r.media_urls,
        r.view_count,
        r.created_at,
        r.updated_at,
        u.id AS author_id,
        u.full_name AS author_name,
        u.role AS author_role,
        u.organization AS author_organization
      FROM reports r
      JOIN users u ON r.author_id = u.id
      WHERE r.id = $1;
    `;

    const commentsQuery = `
      SELECT 
        c.id,
        c.content,
        c.is_official_response,
        c.created_at,
        u.full_name AS author_name,
        u.role AS author_role
      FROM comments c
      JOIN users u ON c.author_id = u.id
      WHERE c.report_id = $1
      ORDER BY c.created_at ASC;
    `;

    const [reportResult, commentsResult] = await Promise.all([
      pool.query(reportQuery, [id]),
      pool.query(commentsQuery, [id]),
    ]);

    if (reportResult.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Report not found.' });
    }

    // Increment view count asynchronously
    pool.query('UPDATE reports SET view_count = view_count + 1 WHERE id = $1', [id]).catch(() => {});

    return res.status(200).json({
      success: true,
      data: {
        ...reportResult.rows[0],
        comments: commentsResult.rows,
      },
    });
  } catch (error) {
    console.error('[ReportsController.getReportById] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error retrieving report details.' });
  }
};

/**
 * PATCH /api/reports/:id/status
 * Secure & Restricted: Moderators and Admins update issue status.
 */
export const updateReportStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!status || !VALID_STATUSES.includes(status)) {
    return res.status(400).json({
      success: false,
      error: `Invalid status. Allowed values: ${VALID_STATUSES.join(', ')}`,
    });
  }

  try {
    const updateQuery = `
      UPDATE reports
      SET status = $1
      WHERE id = $2
      RETURNING id, title, status, updated_at;
    `;
    const { rows } = await pool.query(updateQuery, [status, id]);

    if (rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Report not found.' });
    }

    return res.status(200).json({
      success: true,
      message: 'Report status updated successfully.',
      data: rows[0],
    });
  } catch (error) {
    console.error('[ReportsController.updateReportStatus] Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error updating report status.' });
  }
};
