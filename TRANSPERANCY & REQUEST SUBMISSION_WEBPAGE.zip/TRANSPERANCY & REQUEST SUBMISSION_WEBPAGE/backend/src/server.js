import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import reportsRoutes from './routes/reportsRoutes.js';
import { pool } from './config/db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Security and utility middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('combined'));
}

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    const dbCheck = await pool.query('SELECT 1 AS healthy');
    return res.status(200).json({
      status: 'UP',
      timestamp: new Date().toISOString(),
      database: dbCheck.rows.length > 0 ? 'CONNECTED' : 'DEGRADED',
      environment: process.env.NODE_ENV || 'development',
    });
  } catch (error) {
    return res.status(503).json({
      status: 'DOWN',
      timestamp: new Date().toISOString(),
      database: 'DISCONNECTED',
      error: error.message,
    });
  }
});

// API Routes
const apiPrefix = process.env.API_PREFIX || '/api';
app.use(`${apiPrefix}/auth`, authRoutes);
app.use(`${apiPrefix}/reports`, reportsRoutes);

// Root informational endpoint
app.get('/', (req, res) => {
  res.json({
    platform: 'Transparency Youth Network API',
    version: '1.0.0',
    documentation: `${apiPrefix}/docs`,
    endpoints: {
      health: '/health',
      auth: `${apiPrefix}/auth`,
      reports: `${apiPrefix}/reports`,
    },
  });
});

// 404 Not Found Handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: `Cannot ${req.method} ${req.originalUrl} - Endpoint not found.`,
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Global Error Handler]:', err);
  const status = err.status || 500;
  res.status(status).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'An unexpected server error occurred.' : err.message,
  });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`[Server] Transparency Youth Network Backend running on port ${PORT}`);
    console.log(`[Server] Health check available at http://localhost:${PORT}/health`);
  });
}

export default app;