/**
 * Standalone Integration & Unit Test Suite for Transparency Youth Network
 * Zero-dependency: Uses Node.js built-in 'node:assert' and 'node:crypto'.
 *
 * Validates Test Cases:
 * - TC-AUTH-01: Valid JWT generation and claims verification
 * - TC-AUTH-03: Rejection of unauthenticated requests
 * - TC-AUTH-04: Rejection of expired tokens
 * - TC-REP-01: Valid civic report submission with GPS coordinates
 * - TC-REP-02: Rejection of missing required fields and short description
 * - TC-REP-03: Rejection of out-of-bounds latitude/longitude coordinates
 * - TC-RBAC-01: Denial of unauthorized status modification by youth role
 * - TC-RBAC-02: Verification of status modification permission for moderator
 * - TC-RBAC-03: Verification of admin moderation permissions
 */

import assert from 'node:assert/strict';
import crypto from 'node:crypto';

const JWT_SECRET = process.env.JWT_SECRET || 'test_super_secret_civic_key_1234567890';

// Built-in RFC 7519 HMAC-SHA256 JWT implementation
function base64UrlEncode(str) {
  return Buffer.from(str)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str) {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  return Buffer.from(base64, 'base64').toString();
}

function signJWT(payload, secret, expiresInSeconds = 3600) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const exp = Math.floor(Date.now() / 1000) + expiresInSeconds;
  const fullPayload = { ...payload, exp };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));

  const signature = crypto
    .createHmac('sha256', secret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

function verifyJWT(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed JWT token structure');
  }

  const [encodedHeader, encodedPayload, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', secret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  if (signature !== expectedSig) {
    throw new Error('Invalid token signature');
  }

  const payload = JSON.parse(base64UrlDecode(encodedPayload));
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    const error = new Error('Token has expired');
    error.name = 'TokenExpiredError';
    throw error;
  }

  return payload;
}

console.log('================================================================');
console.log('RUNNING TEST SUITE: Transparency Youth Network Core Modules');
console.log('================================================================\n');

let passedTests = 0;
let failedTests = 0;

function runTest(testId, description, fn) {
  try {
    fn();
    console.log(`[PASS] ${testId}: ${description}`);
    passedTests++;
  } catch (error) {
    console.error(`[FAIL] ${testId}: ${description}`);
    console.error(`       Error: ${error.message}`);
    failedTests++;
  }
}

// -----------------------------------------------------------------------------
// Authentication & JWT Unit Tests
// -----------------------------------------------------------------------------

runTest('TC-AUTH-01', 'Generate and verify valid JWT claims for youth role', () => {
  const payload = {
    id: '11111111-1111-1111-1111-111111111111',
    email: 'aarav.patel@youthnet.org',
    role: 'youth',
    full_name: 'Aarav Patel',
  };
  const token = signJWT(payload, JWT_SECRET, 3600);
  assert.ok(token, 'Token string should be generated');

  const decoded = verifyJWT(token, JWT_SECRET);
  assert.equal(decoded.id, payload.id);
  assert.equal(decoded.role, 'youth');
  assert.equal(decoded.email, payload.email);
});

runTest('TC-AUTH-03', 'Reject requests without Bearer authorization token', () => {
  const mockHeaders = {};
  const authHeader = mockHeaders['authorization'];
  assert.equal(authHeader, undefined, 'Authorization header is absent');

  let errorResponse = null;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    errorResponse = { status: 401, error: 'Access denied. Missing Authorization header.' };
  }
  assert.equal(errorResponse.status, 401);
});

runTest('TC-AUTH-04', 'Reject expired JWT tokens', () => {
  const payload = { id: 'expired-user', role: 'youth' };
  // Expire immediately by passing negative duration
  const token = signJWT(payload, JWT_SECRET, -10);

  assert.throws(
    () => {
      verifyJWT(token, JWT_SECRET);
    },
    (err) => err.name === 'TokenExpiredError',
    'Should throw TokenExpiredError'
  );
});

// -----------------------------------------------------------------------------
// Report Validation & Coordinate Boundaries
// -----------------------------------------------------------------------------

function validateReportInput(data) {
  const errors = [];
  if (!data.title || data.title.trim().length < 5) {
    errors.push('Title is required and must be at least 5 characters long.');
  }
  if (!data.description || data.description.trim().length < 20) {
    errors.push('Description is required and must be at least 20 characters long.');
  }
  if (!data.category) {
    errors.push('A valid category is required.');
  }
  const lat = parseFloat(data.latitude);
  const lng = parseFloat(data.longitude);
  if (isNaN(lat) || lat < -90 || lat > 90) {
    errors.push('Latitude must be between -90 and 90.');
  }
  if (isNaN(lng) || lng < -180 || lng > 180) {
    errors.push('Longitude must be between -180 and 180.');
  }
  return { isValid: errors.length === 0, errors };
}

runTest('TC-REP-01', 'Pass validation for valid report data and GPS coordinates', () => {
  const validReport = {
    title: 'Broken Streetlight on 5th Ave',
    description: 'The street lamp has been broken for 2 weeks creating safety concerns.',
    category: 'public_safety',
    latitude: 22.303894,
    longitude: 70.80216,
  };
  const result = validateReportInput(validReport);
  assert.equal(result.isValid, true);
  assert.equal(result.errors.length, 0);
});

runTest('TC-REP-02', 'Reject report missing title and short description', () => {
  const invalidReport = {
    title: '',
    description: 'Too short',
    category: 'infrastructure',
    latitude: 22.303,
    longitude: 70.802,
  };
  const result = validateReportInput(invalidReport);
  assert.equal(result.isValid, false);
  assert.ok(result.errors.some((e) => e.includes('Title is required')));
  assert.ok(result.errors.some((e) => e.includes('Description is required')));
});

runTest('TC-REP-03', 'Reject coordinates out of permissible geographic bounds', () => {
  const outOfBoundsReport = {
    title: 'Illegal Dumping Site',
    description: 'Industrial waste dumped alongside forest reserve pathway.',
    category: 'environment',
    latitude: 105.45, // Invalid > 90
    longitude: 70.802,
  };
  const result = validateReportInput(outOfBoundsReport);
  assert.equal(result.isValid, false);
  assert.ok(result.errors.some((e) => e.includes('Latitude must be between -90 and 90')));
});

// -----------------------------------------------------------------------------
// Role-Based Access Control (RBAC) Logic
// -----------------------------------------------------------------------------

function checkPermission(userRole, allowedRoles) {
  if (!userRole || !allowedRoles.includes(userRole)) {
    return { status: 403, error: 'Forbidden. Insufficient permissions.' };
  }
  return { status: 200, success: true };
}

runTest('TC-RBAC-01', 'Deny youth role from modifying report status', () => {
  const youthRole = 'youth';
  const permission = checkPermission(youthRole, ['moderator', 'admin']);
  assert.equal(permission.status, 403);
  assert.ok(permission.error.includes('Forbidden'));
});

runTest('TC-RBAC-02', 'Allow moderator role to modify report status', () => {
  const modRole = 'moderator';
  const permission = checkPermission(modRole, ['moderator', 'admin']);
  assert.equal(permission.status, 200);
  assert.equal(permission.success, true);
});

runTest('TC-RBAC-03', 'Allow admin role full moderation and administration access', () => {
  const adminRole = 'admin';
  const permission = checkPermission(adminRole, ['moderator', 'admin']);
  assert.equal(permission.status, 200);
  assert.equal(permission.success, true);
});

console.log('\n================================================================');
console.log(`SUMMARY: ${passedTests} Passed, ${failedTests} Failed.`);
console.log('================================================================');

if (failedTests > 0) {
  process.exit(1);
} else {
  console.log('All automated architectural test suites completed successfully!\n');
}
