'use client';

import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import CivicMetricsBanner from '../components/CivicMetricsBanner';
import PublicTransparencyDashboard from '../components/PublicTransparencyDashboard';
import SubmitReportForm from '../components/SubmitReportForm';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [lastSubmittedReport, setLastSubmittedReport] = useState(null);

  const handleReportSubmitted = (newReport) => {
    setLastSubmittedReport(newReport);
    // Switch to feed view after brief delay so user sees their new report
    setTimeout(() => {
      setActiveTab('dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen pb-12">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <CivicMetricsBanner reportsCount="2,483" />

        {activeTab === 'dashboard' ? (
          <div>
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                  Public Transparency Registry
                </h2>
                <p className="text-sm text-slate-600">
                  Real-time status of civic complaints, audits, and municipal resolutions.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('submit')}
                className="inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
              >
                + Submit New Report
              </button>
            </div>
            <PublicTransparencyDashboard key={lastSubmittedReport ? lastSubmittedReport.id : 'initial'} />
          </div>
        ) : (
          <div>
            <div className="mb-4">
              <button
                onClick={() => setActiveTab('dashboard')}
                className="text-sm font-semibold text-blue-600 hover:text-blue-800"
              >
                ← Back to Transparency Feed
              </button>
            </div>
            <SubmitReportForm onReportSubmitted={handleReportSubmitted} />
          </div>
        )}
      </main>
    </div>
  );
}
