import './globals.css';

export const metadata = {
  title: 'Transparency Youth Network - Open Civic Platform',
  description: 'Empowering youth to report local civic issues and track public infrastructure transparently.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased min-h-screen flex flex-col justify-between">
        <main className="flex-grow">{children}</main>
        <footer className="bg-white border-t border-slate-200 py-8 text-center text-xs text-slate-500">
          <p>© 2026 Transparency Youth Network. Open Source Civic Technology Initiative.</p>
        </footer>
      </body>
    </html>
  );
}
