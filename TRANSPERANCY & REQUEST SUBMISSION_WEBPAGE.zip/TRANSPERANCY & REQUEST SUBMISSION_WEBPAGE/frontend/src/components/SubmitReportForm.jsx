'use client';

import React, { useState } from 'react';

const CATEGORIES = [
  { value: 'infrastructure', label: 'Infrastructure & Roads' },
  { value: 'sanitation', label: 'Sanitation & Waste' },
  { value: 'education', label: 'Schools & Education' },
  { value: 'environment', label: 'Parks & Environment' },
  { value: 'public_safety', label: 'Public Safety' },
  { value: 'governance', label: 'Governance & Transparency' },
  { value: 'other', label: 'Other Civic Issue' },
];

export default function SubmitReportForm({ onReportSubmitted }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'infrastructure',
    latitude: '',
    longitude: '',
    address_text: '',
  });

  const [loading, setLoading] = useState(false);
  const [geoLocating, setGeoLocating] = useState(false);
  const [errors, setErrors] = useState([]);
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDetectLocation = () => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      setErrors(['Geolocation is not supported by your current browser.']);
      return;
    }

    setGeoLocating(true);
    setErrors([]);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormData((prev) => ({
          ...prev,
          latitude: position.coords.latitude.toFixed(6),
          longitude: position.coords.longitude.toFixed(6),
        }));
        setGeoLocating(false);
      },
      (geoError) => {
        setErrors([`Unable to fetch location: ${geoError.message}`]);
        setGeoLocating(false);
      },
      { timeout: 15000, enableHighAccuracy: false, maximumAge: 60000 }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors([]);
    setSuccessMessage('');

    // In a production app, the token is extracted from authentication context or secure session
    // For local evaluation, we fallback to a demo youth token if none exists in localStorage
    let token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (!token) {
      token = 'mock_youth_jwt_token_for_demo';
    }

    const apiUrl = 'http://localhost:5050';
    
    try {
      const response = await fetch(`${apiUrl}/api/reports`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.errors) {
          setErrors(result.errors);
        } else {
          setErrors([result.error || 'Failed to submit report.']);
        }
        return;
      }

      setSuccessMessage('Your report has been submitted to the public registry.');
      setFormData({
        title: '',
        description: '',
        category: 'infrastructure',
        latitude: '',
        longitude: '',
        address_text: '',
      });

      if (onReportSubmitted) {
        onReportSubmitted(result.data);
      }
    } catch (err) {
      setErrors(['Network connection failure. Please verify the backend API is online.']);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-sm border border-slate-200 p-6 md:p-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Submit Community Issue</h2>
        <p className="text-sm text-slate-500 mt-1">
          Make local governance transparent. File an issue directly to the public registry.
        </p>
      </div>

      {errors.length > 0 && (
        <div className="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
          <p className="font-semibold mb-1">Please correct the following:</p>
          <ul className="list-disc list-inside space-y-0.5">
            {errors.map((err, index) => (
              <li key={index}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      {successMessage && (
        <div className="mb-6 p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium">
          {successMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="title" className="block text-sm font-semibold text-slate-700 mb-1">
            Report Title *
          </label>
          <input
            type="text"
            id="title"
            name="title"
            required
            value={formData.title}
            onChange={handleChange}
            placeholder="e.g., Broken water pipeline on Main St."
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-semibold text-slate-700 mb-1">
            Category *
          </label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm bg-white"
          >
            {CATEGORIES.map((cat) => (
              <option key={cat.value} value={cat.value}>
                {cat.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-semibold text-slate-700 mb-1">
            Detailed Description *
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            required
            value={formData.description}
            onChange={handleChange}
            placeholder="Describe the problem, affected community members, and history..."
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="block text-sm font-semibold text-slate-700">Geographic Coordinates *</label>
            <button
              type="button"
              onClick={handleDetectLocation}
              disabled={geoLocating}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 disabled:text-slate-400"
            >
              {geoLocating ? 'Detecting GPS...' : 'Auto-detect GPS Location'}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="number"
              step="any"
              name="latitude"
              required
              placeholder="Latitude (e.g., 22.3039)"
              value={formData.latitude}
              onChange={handleChange}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
            <input
              type="number"
              step="any"
              name="longitude"
              required
              placeholder="Longitude (e.g., 70.8022)"
              value={formData.longitude}
              onChange={handleChange}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label htmlFor="address_text" className="block text-sm font-semibold text-slate-700 mb-1">
            Address / Landmark Description
          </label>
          <input
            type="text"
            id="address_text"
            name="address_text"
            value={formData.address_text}
            onChange={handleChange}
            placeholder="Opposite City Library, Kalavad Road"
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow transition-colors disabled:bg-slate-400"
        >
          {loading ? 'Submitting to Public Registry...' : 'Submit Issue to Public Ledger'}
        </button>
      </form>
    </div>
  );
}
