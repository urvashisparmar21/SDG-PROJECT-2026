import React from 'react';

export default function CivicMetricsBanner({ reportsCount = 0 }) {
  const metrics = [
    { label: 'Verified Reports', value: reportsCount || '2,480+', change: '+14% this month' },
    { label: 'Resolution Rate', value: '78.4%', change: 'Avg. 3.2 days' },
    { label: 'Youth Volunteers', value: '14,200', change: 'Across 48 wards' },
    { label: 'Open Civic Projects', value: '184', change: 'Active oversight' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {metrics.map((metric, idx) => (
        <div
          key={idx}
          className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:border-slate-300 transition-colors"
        >
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
            {metric.label}
          </p>
          <p className="text-2xl font-extrabold text-slate-900 tracking-tight">
            {metric.value}
          </p>
          <p className="text-xs font-medium text-emerald-600 mt-1">
            {metric.change}
          </p>
        </div>
      ))}
    </div>
  );
}
