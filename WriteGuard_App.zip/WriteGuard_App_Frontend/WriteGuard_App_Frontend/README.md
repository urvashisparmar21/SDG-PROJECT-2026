# WriteGuard App Frontend

This is an application-style frontend, not a static landing page.

## Functional features
- Persistent document library using localStorage
- Real writing editor with autosave
- Live word/character/sentence/reading-time statistics
- Live writing-health feedback
- New document creation and document switching
- TXT/MD/CSV/JSON import
- Drag/drop-ready file workflow
- TXT export
- AI-detector heuristic
- Internal repeated-phrase originality checker
- Deterministic text humanizer
- Extractive summarizer
- Persistent analysis history
- Real light/dark theme with persistence
- Profile/display-name settings
- Local-data deletion
- Responsive mobile navigation

## Run
Open `index.html` directly or use VS Code Live Server.

## Important
A true generative AI service or internet-wide plagiarism database cannot be implemented safely as frontend-only code. Those require a backend/API. This frontend does not pretend otherwise; its included analysis tools execute actual browser-side processing.
